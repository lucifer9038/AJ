public class GenericMethodExample {

    // Generic method to print an array of any type
    public static <T> void printArray(T[] array) {
        for (T element : array) {
            System.out.println(element);
        }
    }

    public static void main(String[] args) {
        // Integer array
        Integer[] intArray = {1, 2, 3, 4, 5};
        System.out.println("Integer Array:");
        printArray(intArray);  // Calling generic method with Integer array

        // String array
        String[] strArray = {"Hello", "World", "Generic", "Methods"};
        System.out.println("\nString Array:");
        printArray(strArray);  // Calling generic method with String array

        // Double array
        Double[] doubleArray = {1.1, 2.2, 3.3, 4.4};
        System.out.println("\nDouble Array:");
        printArray(doubleArray);  // Calling generic method with Double array
    }
}
