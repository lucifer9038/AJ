package mypack;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class EmployeeAspect {

    @Pointcut("execution(* mypack.Employee.get*(..))")
    public void getterMethods() {}

    @Pointcut("execution(* mypack.Employee.set*(..))")
    public void setterMethods() {}

    @Before("getterMethods() || setterMethods()")
    public void beforeGetterOrSetter() {
        System.out.println("Aspect triggered: Before getter or setter method execution.");
    }
}
