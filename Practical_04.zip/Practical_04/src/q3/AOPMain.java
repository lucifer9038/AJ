package q3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPMain {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("questin3.xml");

        Image image = context.getBean(Image.class);

        image.loadImage();
        image.displayImage();
        image.deleteImage();
    }
}
