package q3;

public class Image {
    public void loadImage() {
        System.out.println("Image is being loaded.");
    }

    public void displayImage() {
        System.out.println("Image is being displayed.");
    }

    public void deleteImage() {
        System.out.println("Image is being deleted.");
    }
}
