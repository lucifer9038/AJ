package q3;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class ImageAspect {

    @Pointcut("execution(* q3.Image.load*(..))")
    public void loadMethods() {}

    @Pointcut("execution(* q3.Image.display*(..))")
    public void displayMethods() {}

    @Pointcut("execution(* q3.Image.delete*(..))")
    public void deleteMethods() {}

    @Before("loadMethods()")
    public void beforeLoad() {
        System.out.println("Before loading the image.");
    }

    @Before("displayMethods()")
    public void beforeDisplay() {
        System.out.println("Before displaying the image.");
    }

    @Before("deleteMethods()")
    public void beforeDelete() {
        System.out.println("Before deleting the image.");
    }
}