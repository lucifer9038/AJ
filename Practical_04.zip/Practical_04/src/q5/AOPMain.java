package q5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPMain {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("question5.xml");

        Order order = context.getBean(Order.class);

        order.placeOrder();
        order.cancelOrder();
        order.trackOrder();
    }
}