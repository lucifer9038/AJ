package q5;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class OrderAspect {

    @After("execution(* q5.Order.*(..))")
    public void logAfterMethodExecution() {
        System.out.println("Logging: A method in Order class has been executed.");
    }
}
