package q2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AOPMain {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("question2.xml");

        Employee employee = context.getBean(Employee.class);
        employee.setName("Alice");
        employee.setId(123);
        employee.displayInfo();
    }
}