package q2;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Aspect
public class EmployeeAspect {

    private static final Logger logger = LoggerFactory.getLogger(EmployeeAspect.class);

    // Pointcut for public methods in the Employee class
    @Before("execution(public * q2.Employee.*(..))")
    public void logBeforeMethodExecution() {
        logger.info("A public method in Employee is about to execute.");
    }
}
