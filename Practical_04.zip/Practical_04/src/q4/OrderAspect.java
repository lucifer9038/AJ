package q4;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class OrderAspect {

    @Pointcut("execution(* q4.Order.place*(..))")
    public void placeMethods() {}

    @Pointcut("execution(* q4.Order.cancel*(..))")
    public void cancelMethods() {}

    @Before("placeMethods() || cancelMethods()")
    public void logBeforePlaceOrCancel() {
        System.out.println("Logging: Order is being placed or canceled.");
    }
}
