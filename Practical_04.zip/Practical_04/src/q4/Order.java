package q4;

public class Order {
    public void placeOrder() {
        System.out.println("Order has been placed.");
    }

    public void cancelOrder() {
        System.out.println("Order has been canceled.");
    }

    public void trackOrder() {
        System.out.println("Tracking order.");
    }
}
