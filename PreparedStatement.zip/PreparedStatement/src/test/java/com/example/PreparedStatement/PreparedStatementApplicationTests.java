package com.example.PreparedStatement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PreparedStatementApplicationTests {

	@Test
	void contextLoads() {
	}

}
