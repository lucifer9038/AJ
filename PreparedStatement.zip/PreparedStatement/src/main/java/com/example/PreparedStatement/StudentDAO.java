package com.example.PreparedStatement;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class StudentDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // Method to add a student to the database using PreparedStatement
    public void addStudent(Student student) {
        String query = "INSERT INTO StudentMaster (RollNo, Name, Semester, Course) VALUES (?, ?, ?, ?)";
        jdbcTemplate.update(query, student.getRollNo(), student.getName(), student.getSemester(), student.getCourse());
    }

    // Method to fetch all students from the database
    public List<Student> getAllStudents() {
        String query = "SELECT * FROM StudentMaster";
        return jdbcTemplate.query(query, new RowMapper<Student>() {
            @Override
            public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
                Student student = new Student();
                student.setRollNo(rs.getInt("RollNo"));
                student.setName(rs.getString("Name"));
                student.setSemester(rs.getString("Semester"));
                student.setCourse(rs.getString("Course"));
                return student;
            }
        });
    }
}

