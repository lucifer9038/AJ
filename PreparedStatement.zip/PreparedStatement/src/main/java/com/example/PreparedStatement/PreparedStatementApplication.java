package com.example.PreparedStatement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class PreparedStatementApplication implements CommandLineRunner {

    @Autowired
    private StudentDAO studentDAO;

    public static void main(String[] args) {
        SpringApplication.run(PreparedStatementApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // Create a new student and add to the database
        Student student = new Student();
        student.setRollNo(1);
        student.setName("John Doe");
        student.setSemester("Spring 2024");
        student.setCourse("Computer Science");

        studentDAO.addStudent(student);
        System.out.println("Student added successfully!");

        // Fetch all students from the database
        List<Student> students = studentDAO.getAllStudents();
        for (Student s : students) {
            System.out.println("RollNo: " + s.getRollNo() + ", Name: " + s.getName() + ", Semester: " + s.getSemester() + ", Course: " + s.getCourse());
        }
    }
}

////
//CREATE TABLE StudentMaster (
//	    RollNo INT PRIMARY KEY,
//	    Name VARCHAR(100),
//	    Semester VARCHAR(50),
//	    Course VARCHAR(100)
//	);


