package com.example.jdbc.service;

import com.example.jdbc.dao.StudentDAO;
import com.example.jdbc.model.Student;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StudentService {
    private final StudentDAO studentDAO;

    public StudentService(StudentDAO studentDAO) {
        this.studentDAO = studentDAO;
    }

    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }

    public Student getStudentById(int id) {
        return studentDAO.getStudentById(id);
    }

    public int addStudent(Student student) {
        return studentDAO.addStudent(student);
    }

    public int updateStudent(Student student) {
        return studentDAO.updateStudent(student);
    }

    public int deleteStudent(int id) {
        return studentDAO.deleteStudent(id);
    }
}
