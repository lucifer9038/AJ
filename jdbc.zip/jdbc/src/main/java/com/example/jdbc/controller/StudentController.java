package com.example.jdbc.controller;

import com.example.jdbc.model.Student;
import com.example.jdbc.service.StudentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {
    private final StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    // Get all students
    @GetMapping
    public List<Student> getAllStudents() {
        return studentService.getAllStudents();
    }

    // Get a student by ID
    @GetMapping("/{id}")
    public ResponseEntity<Student> getStudentById(@PathVariable int id) {
        Student student = studentService.getStudentById(id);
        return student != null ? ResponseEntity.ok(student) : ResponseEntity.notFound().build();
    }

    // Add a new student
    @PostMapping
    public ResponseEntity<String> addStudent(@RequestBody Student student) {
        int result = studentService.addStudent(student);
        return result > 0 ? ResponseEntity.ok("Student added successfully!") :
                ResponseEntity.status(500).body("Error adding student.");
    }

    // Update a student
    @PutMapping("/{id}")
    public ResponseEntity<String> updateStudent(@PathVariable int id, @RequestBody Student student) {
        student.setId(id); // Ensure the ID from the URL is used
        int result = studentService.updateStudent(student);
        return result > 0 ? ResponseEntity.ok("Student updated successfully!") :
                ResponseEntity.status(500).body("Error updating student.");
    }

    // Delete a student
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteStudent(@PathVariable int id) {
        int result = studentService.deleteStudent(id);
        return result > 0 ? ResponseEntity.ok("Student deleted successfully!") :
                ResponseEntity.status(500).body("Error deleting student.");
    }
}
