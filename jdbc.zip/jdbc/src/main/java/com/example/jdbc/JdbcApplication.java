package com.example.jdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(JdbcApplication.class, args);
	}

}

//1. Get All Students
//URL: GET /students
//
//2. Get a Student by ID
//URL: GET /students/{id}
//Example: GET /students/1
//
//3. Add a New Student
//URL: POST /students
//
//4. Update an Existing Student
//URL: PUT /students/{id}
//Example: PUT /students/3
//
//5. Delete a Student
//URL: DELETE /students/{id}
//Example: DELETE /students/3
