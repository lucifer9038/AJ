package conversion;

@FunctionalInterface
interface Conversion {
    double convert(double value); // abstract method to convert a value
}

public class ConversionExample {
    public static void main(String[] args) {

        // Lambda expression for converting Fahrenheit to Celsius
        Conversion fahrenheitToCelsius = (fahrenheit) -> (fahrenheit - 32) * 5 / 9;
        
        // Lambda expression for converting Kilometers to Miles
        Conversion kilometersToMiles = (kilometers) -> kilometers * 0.621371;

        // Test the conversions
        double fahrenheit = 98.6;
        double kilometers = 100.0;

        double celsius = fahrenheitToCelsius.convert(fahrenheit);
        double miles = kilometersToMiles.convert(kilometers);

        // Display the results
        System.out.println(fahrenheit + " Fahrenheit is equal to " + celsius + " Celsius.");
        System.out.println(kilometers + " Kilometers is equal to " + miles + " Miles.");
    }
}
