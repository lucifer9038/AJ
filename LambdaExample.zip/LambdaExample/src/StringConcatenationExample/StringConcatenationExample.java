package StringConcatenationExample;

@FunctionalInterface
interface StringConcatenation {
    String concatenate(String str1, String str2); // abstract method to concatenate two strings
}

public class StringConcatenationExample {
    public static void main(String[] args) {

        // Lambda expression to concatenate two strings
        StringConcatenation concatenation = (str1, str2) -> str1 + str2;

        // Test the string concatenation
        String result = concatenation.concatenate("Hello, ", "World!");

        // Display the result
        System.out.println("Concatenated String: " + result);
    }
}

