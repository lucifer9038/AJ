package HelloWorldLambda;

@FunctionalInterface
interface Printer {
    void print(); // abstract method to print a message
}

public class HelloWorldLambda {
    public static void main(String[] args) {
        // Lambda expression to print "Hello World"
        Printer printer = () -> System.out.println("Hello World");

        // Calling the print method
        printer.print();
    }
}

