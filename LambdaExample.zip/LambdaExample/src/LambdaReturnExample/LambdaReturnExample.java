package LambdaReturnExample;

@FunctionalInterface
interface MathOperation {
    int operation(int a, int b); // abstract method with two parameters
}

public class LambdaReturnExample {
    public static void main(String[] args) {
        
        // Lambda expression with the return keyword
        MathOperation additionWithReturn = (a, b) -> {
            return a + b; // return statement is used
        };
        
        // Lambda expression without the return keyword
        MathOperation additionWithoutReturn = (a, b) -> a + b; // return is implicit
        
        // Perform the operations and display the results
        System.out.println("Addition with return keyword: " + additionWithReturn.operation(5, 3));
        System.out.println("Addition without return keyword: " + additionWithoutReturn.operation(5, 3));
    }
}

