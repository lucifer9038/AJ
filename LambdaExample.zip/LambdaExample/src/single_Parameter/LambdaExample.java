package single_Parameter;

@FunctionalInterface
interface Greeting {
    void greet(String name); // abstract method with a single parameter
}

public class LambdaExample {
    public static void main(String[] args) {
        // Lambda expression to implement the greet method
        Greeting greeting = (name) -> System.out.println("Hello, " + name + "!");
        
        // Calling the greet method with a single argument
        greeting.greet("John");
        greeting.greet("Alice");
    }
}

