package mypack;

import org.springframework.aop.framework.ProxyFactory;

public class Main {
    public static void main(String[] args) {
        // Create the target object
        StudentService target = new StudentServiceImpl();

        // Create ProxyFactory
        ProxyFactory factory = new ProxyFactory(target);

        // Add advice (LoggingAspect)
        factory.addAdvice(new LoggingAspect());

        // Get the proxy object
        StudentService proxy = (StudentService) factory.getProxy();

        // Call the method via proxy
        System.out.println("Calling getStudent()...");
        String student = proxy.getStudent();
        System.out.println("Student: " + student);
    }
}
