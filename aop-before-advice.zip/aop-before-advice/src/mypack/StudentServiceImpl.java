package mypack;

public class StudentServiceImpl implements StudentService {
    @Override
    public String getStudent() {
        System.out.println("Executing getStudent() method...");
        return "John Doe";
    }
}
