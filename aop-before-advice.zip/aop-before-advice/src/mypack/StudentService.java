package mypack;

public interface StudentService {
    String getStudent();
}
