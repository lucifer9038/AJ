package mypack;

public class UserService {
    private MessageService messageService;

    // Setter method for dependency injection
    public void setMessageService(MessageService messageService) {
        this.messageService = messageService;
    }

    public void processUser(String message) {
        System.out.println("Processing user...");
        messageService.sendMessage(message);
    }
}
