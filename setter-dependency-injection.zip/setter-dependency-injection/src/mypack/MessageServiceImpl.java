package mypack;

public class MessageServiceImpl implements MessageService {

    @Override
    public void sendMessage(String message) {
        System.out.println("Message Sent: " + message);
    }
}
