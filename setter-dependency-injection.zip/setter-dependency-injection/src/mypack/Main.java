package mypack;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main(String[] args) {
        // Load Spring context
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

        // Get the UserService bean
        UserService userService = (UserService) context.getBean("userService");

        // Use the service to process the user and send the message
        userService.processUser("Hello, Spring!");
    }
}
