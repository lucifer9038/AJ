package mypack;

public interface MessageService {
    void sendMessage(String message);
}
