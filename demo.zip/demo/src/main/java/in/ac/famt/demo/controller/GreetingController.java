package in.ac.famt.demo.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import in.ac.famt.demo.model.Greeting;

@RestController
public class GreetingController {
    private static final String template = "Hello, %s!";
    private static long counter = 0;

    @GetMapping("/greeting")
    public Greeting greeting(@RequestParam(value = "name", defaultValue = "World") String name) {
        return new Greeting(++counter, String.format(template, name));
    }
}

//http://localhost:8080/greeting
//http://localhost:8080/greeting?name=John